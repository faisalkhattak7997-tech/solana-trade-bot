import requests
import os
import json
import time
from datetime import datetime

# ── CONFIG ──────────────────────────────────────────────
BUY_AMOUNT_SOL = 0.05          # SOL per trade (~$4-5)
TAKE_PROFIT_PCT = 50           # sell when +50%
STOP_LOSS_PCT = 15             # sell when -15%
MIN_LIQUIDITY = 50000          # minimum $50k liquidity
MIN_VOLUME_24H = 100000        # minimum $100k 24h volume
MAX_AGE_HOURS = 24             # only tokens newer than 24h
MIN_PRICE_CHANGE = 20          # minimum 20% gain in 24h
SLIPPAGE = 0.15                # 15% slippage tolerance
# ────────────────────────────────────────────────────────

DEXSCREENER_URL = "https://api.dexscreener.com/latest/dex/tokens/solana"
DEXSCREENER_TRENDING = "https://api.dexscreener.com/latest/dex/search?q=solana"

def get_trending_tokens():
    """Fetch trending Solana tokens from DexScreener"""
    try:
        response = requests.get(
            "https://api.dexscreener.com/latest/dex/tokens/So11111111111111111111111111111111111111112",
            timeout=10
        )
        
        # Get trending pairs
        trending_response = requests.get(
            "https://api.dexscreener.com/latest/dex/search?q=solana",
            timeout=10
        )
        
        if trending_response.status_code == 200:
            data = trending_response.json()
            pairs = data.get("pairs", [])
            return pairs
        return []
    except Exception as e:
        print(f"Error fetching tokens: {e}")
        return []

def analyze_token(pair):
    """Analyze a token pair and return True if it meets buying criteria"""
    try:
        # Basic checks
        if not pair:
            return False
            
        chain = pair.get("chainId", "")
        if chain != "solana":
            return False
        
        # Liquidity check
        liquidity = pair.get("liquidity", {}).get("usd", 0)
        if liquidity < MIN_LIQUIDITY:
            return False
            
        # Volume check
        volume_24h = pair.get("volume", {}).get("h24", 0)
        if volume_24h < MIN_VOLUME_24H:
            return False
        
        # Price change check
        price_change_24h = pair.get("priceChange", {}).get("h24", 0)
        if price_change_24h < MIN_PRICE_CHANGE:
            return False
        
        # Age check - only trade newer tokens
        pair_created_at = pair.get("pairCreatedAt", 0)
        if pair_created_at:
            age_hours = (time.time() * 1000 - pair_created_at) / (1000 * 3600)
            if age_hours > MAX_AGE_HOURS:
                return False
        
        return True
        
    except Exception as e:
        print(f"Error analyzing token: {e}")
        return False

def log_signal(pair, action):
    """Log trading signals to a file"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    token_name = pair.get("baseToken", {}).get("name", "Unknown")
    token_symbol = pair.get("baseToken", {}).get("symbol", "???")
    price = pair.get("priceUsd", "0")
    volume = pair.get("volume", {}).get("h24", 0)
    liquidity = pair.get("liquidity", {}).get("usd", 0)
    price_change = pair.get("priceChange", {}).get("h24", 0)
    pair_address = pair.get("pairAddress", "")
    
    log_entry = {
        "timestamp": timestamp,
        "action": action,
        "token": f"{token_name} ({token_symbol})",
        "price_usd": price,
        "volume_24h": f"${volume:,.0f}",
        "liquidity": f"${liquidity:,.0f}",
        "price_change_24h": f"{price_change}%",
        "pair_address": pair_address,
        "dexscreener_url": f"https://dexscreener.com/solana/{pair_address}"
    }
    
    print(f"\n{'='*50}")
    print(f"🚨 SIGNAL: {action}")
    print(f"Token: {token_name} ({token_symbol})")
    print(f"Price: ${price}")
    print(f"24h Volume: ${volume:,.0f}")
    print(f"Liquidity: ${liquidity:,.0f}")
    print(f"24h Change: {price_change}%")
    print(f"DexScreener: https://dexscreener.com/solana/{pair_address}")
    print(f"{'='*50}\n")
    
    # Save to signals log
    try:
        with open("signals.json", "a") as f:
            f.write(json.dumps(log_entry) + "\n")
    except:
        pass

def run_bot():
    """Main bot loop"""
    print(f"\n🤖 SOLANA DEX BOT STARTED")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"📊 Scanning DexScreener for Solana tokens...")
    print(f"Settings: Buy={BUY_AMOUNT_SOL} SOL | TP={TAKE_PROFIT_PCT}% | SL={STOP_LOSS_PCT}%")
    print(f"Filters: Min Liquidity=${MIN_LIQUIDITY:,} | Min Volume=${MIN_VOLUME_24H:,} | Min Change={MIN_PRICE_CHANGE}%\n")
    
    # Fetch trending tokens
    pairs = get_trending_tokens()
    print(f"📡 Found {len(pairs)} pairs to analyze...")
    
    signals_found = 0
    
    for pair in pairs:
        if analyze_token(pair):
            log_signal(pair, "BUY SIGNAL")
            signals_found += 1
            
            # Limit to top 3 signals per run
            if signals_found >= 3:
                break
    
    if signals_found == 0:
        print("😴 No tokens met the criteria this run. Waiting for next scan...")
    else:
        print(f"\n✅ Found {signals_found} buy signal(s) this run!")
    
    print(f"\n🏁 Bot scan complete at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    run_bot()
